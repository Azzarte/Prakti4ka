module Практика {
}