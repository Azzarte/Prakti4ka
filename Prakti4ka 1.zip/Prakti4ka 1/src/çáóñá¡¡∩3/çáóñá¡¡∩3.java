package Завдання3;

import java.util.Scanner;

public class Завдання3 {
	public static void main(String args[])
	
	{ 
		Scanner in = new Scanner(System.in);
		System.out.print("Number of students: ");
        int n = in.nextInt();
        
        
        System.out.print("Number of apples: ");
        int k = in.nextInt();
        
        System.out.print("everyone get " + k/n + " apples ");
       
        
	}
	
	
		

}
