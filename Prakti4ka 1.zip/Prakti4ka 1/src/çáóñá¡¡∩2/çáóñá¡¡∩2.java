package Завдання2;

public class Завдання2 {
	public static void main(String args[])
	{
		int a = 2450;
		int b = a + 1;
		int c = a - 1;
		System.out.print("The next number fot the nubmer " + a + " is " + b);
		System.out.println();
		System.out.print("The previous for the number " + a + " is " + c);
		
		
		

	}
}
