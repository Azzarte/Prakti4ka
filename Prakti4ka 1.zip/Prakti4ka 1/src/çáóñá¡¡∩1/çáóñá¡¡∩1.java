package Завдання1;

public class Завдання1 {
	public static void main(String args[])
	{
		int a = 100; 
		int b = 150; 
		int c = a + b; 
		System.out.println(c);
	}

}